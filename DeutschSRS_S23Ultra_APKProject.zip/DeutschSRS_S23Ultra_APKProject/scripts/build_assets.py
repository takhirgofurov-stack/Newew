#!/usr/bin/env python3
"""Generate runtime JS and the legacy verb-only JSON from canonical decks.json."""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app" / "src" / "main" / "assets"
SOURCE = ASSETS / "decks.json"

def main() -> None:
    data = json.loads(SOURCE.read_text(encoding="utf-8"))
    expected = {"verbs": 1170, "adverbs": 402, "preps": 67}
    if set(data) != set(expected):
        raise SystemExit(f"Unexpected deck keys: {set(data)}")
    for key, size in expected.items():
        items = data[key]
        if not isinstance(items, list) or len(items) != size:
            raise SystemExit(f"{key}: expected {size} records, got {len(items) if isinstance(items, list) else type(items)}")
        field = "verb" if key == "verbs" else "word"
        names = [str(item.get(field, "")).strip().casefold() for item in items]
        if any(not name for name in names):
            raise SystemExit(f"{key}: empty {field}")
        if len(names) != len(set(names)):
            raise SystemExit(f"{key}: duplicate {field} values")
    chunks = []
    for name, key in (("CARDS", "verbs"), ("ADVERBS", "adverbs"), ("PREPS", "preps")):
        chunks.append(f"const {name}={json.dumps(data[key], ensure_ascii=False, separators=(',', ':'))};")
    (ASSETS / "cards.js").write_text("\n".join(chunks) + "\n", encoding="utf-8")
    # Kept for compatibility with older tooling; generated, never edited by hand.
    (ASSETS / "cards.json").write_text(json.dumps(data["verbs"], ensure_ascii=False, separators=(',', ':')) + "\n", encoding="utf-8")
    print("Generated cards.js and compatibility cards.json from decks.json:", ", ".join(f"{k}={len(v)}" for k,v in data.items()))

if __name__ == "__main__":
    main()

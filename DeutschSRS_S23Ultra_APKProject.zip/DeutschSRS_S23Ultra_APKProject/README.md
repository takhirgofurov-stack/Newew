# Deutsch SRS — Samsung Galaxy S23 Ultra

Android Studio project containing 1170 verb records parsed from the supplied PDF.

Included in this build:
- local 1170-card database;
- two examples per card (generated placeholders; the source PDF does not provide examples);
- Präteritum, Partizip II, Rektion and Russian translation;
- management formatted as `__ + Akk.`, `an + Akk.` etc.;
- SRS: 20 min -> 2 h -> 1 d -> 3 d -> longer intervals;
- four self-ratings;
- typed verb recall;
- daily challenge with own sentences;
- progress stored in WebView localStorage on the phone.

The AI sentence checker is deliberately not embedded with an API key. For real AI checking, add a secure server endpoint and call it from the challenge screen.

Build with Android Studio -> Build APK(s). Debug APK: app/build/outputs/apk/debug/app-debug.apk

## Этап 3 — субтитры к видео (добавлено)
- Экран «Видео» теперь умеет: (а) загрузить готовый файл субтитров `.srt`/`.vtt` и распарсить его локально, либо (б) отправить уже извлечённый звук (`current_audio.m4a`) в твой Cloudflare Worker, который должен переслать его в Gemini и вернуть реплики с таймкодами.
- Во время проигрывания видео активная реплика подсвечивается под плеером; каждое слово тап-абельно → всплывающая карточка (слово + перевод, который можно поправить) → «★ Сохранить» кладёт слово в `db.favorites`.
- Новый экран «★ Избранное» — список сохранённых слов с возможностью удаления.
- **Нужно доработать твой Worker**: см. `WORKER_ADDITIONS.md` — там контракт для двух новых режимов (`mode:'translate'` и `mode:'transcribeSubtitles'`), которые ждёт клиент. Пришли исходник Worker'а — вставлю прямо в него, а не рядом текстом.

## Этап 4 — карточки с вкладками, тап по словам, запасной Worker (добавлено)
- **Тап по любому слову** в чате, в примерах карточек (лицевая и обратная сторона), в синонимах и в субтитрах → карточка слова с переводом и «★ Сохранить». Уже сохранённые слова подчёркнуты точками; дубли не создаются.
- **Обратная сторона карточек** (глаголы, наречия, предлоги) и **карточка в избранном** теперь с тремя вкладками, как в Reverso Context:
  - «Переводы» — варианты перевода + примеры с русским переводом (для глаголов — формы и управление);
  - «Синонимы» — загружаются ИИ (режим `wordDetails`), тап по синониму добавляет его в избранное;
  - «Спряжение» (для глаголов) — Infinitiv, Partizip Präsens/II, Indikativ: Präsens, Präteritum, Perfekt, Plusquamperfekt, Futur I, Futur II. Для 1170 глаголов из колоды считается локально, без ИИ. Для остальных слов вместо неё вкладка «Грамматика» (категория, падеж, артикль, мн. число).
- **Запасной Worker**: в «⚙️ ИИ» можно указать второй адрес. Если основной не ответил (лимит Gemini, сбой, не обновлён), приложение само повторяет запрос на запасном. Исходник: `cloudflare_worker_backup.js` (Groq по умолчанию, бесплатный тариф; подойдёт любой OpenAI-совместимый API).
- Новый режим Worker `wordDetails` добавлен в `cloudflare_worker_gemini.js` и в `cloudflare_worker_backup.js`. Ответ кэшируется на телефоне (`db.wordDetailsCache`).
- **Перевод .srt стал экономнее и возобновляемым**: пачки по 150 реплик вместо 40 (1900 реплик ≈ 13 запросов вместо 48). Если число переводов не совпало, пачка делится пополам и повторяется. При лимите ИИ прогресс сохраняется (`db.srtTr`), в разделе «Видео» появляется «▶ Продолжить перевод» и «💾 Сохранить как есть». С подключённым запасным Worker перевод продолжается на нём автоматически.

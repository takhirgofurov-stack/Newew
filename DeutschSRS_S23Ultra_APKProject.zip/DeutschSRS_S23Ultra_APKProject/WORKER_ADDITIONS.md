# Что нужно добавить в Worker для этапа 3

Я не вижу исходник твоего Worker'а (он создавался в другом чате и не входит в этот
ZIP) — сделал клиент под контракт ниже. Если пришлёшь `worker.js` — вставлю это
прямо в него, подстроив под твой текущий способ вызова Gemini, вместо примера.

Приложение теперь может отправлять два новых `mode`:

## 1. `mode: 'translate'` — перевод одного слова/фразы

Запрос от клиента:
```json
{ "mode": "translate", "word": "Bedürfnis", "sentence": "Er hat ein Bedürfnis nach Ruhe." }
```

Ожидаемый ответ (клиент читает поле `translation`):
```json
{ "translation": "потребность" }
```

Пример обработчика (адаптируй под то, как у тебя уже вызывается Gemini в режиме `chat`):
```js
if (payload.mode === 'translate') {
  const prompt = `Переведи немецкое слово "${payload.word}" на русский с учётом контекста предложения: "${payload.sentence}". Ответь ТОЛЬКО переводом (1-3 слова), без пояснений и кавычек.`;
  const geminiText = await callGemini(prompt); // твоя существующая функция вызова Gemini
  return jsonResponse({ translation: geminiText.trim() });
}
```

## 2. `mode: 'transcribeSubtitles'` — распознавание аудио в субтитры

Запрос от клиента:
```json
{ "mode": "transcribeSubtitles", "mimeType": "audio/mp4", "audioBase64": "<очень длинная строка>" }
```

Ожидаемый ответ — тот же формат `{ text: "..." }`, что уже возвращает твой `chat`,
только внутри `text` должна быть **строка с JSON-массивом реплик** (клиент сам
парсит `text` как JSON и убирает возможные ```json оборачивания):
```json
{ "text": "[{\"start\":1.2,\"end\":3.8,\"de\":\"Guten Morgen!\",\"ru\":\"Доброе утро!\"},...]" }
```

Пример обработчика через REST Gemini API (`generateContent`) с аудио как `inlineData`:
```js
if (payload.mode === 'transcribeSubtitles') {
  const geminiResp = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${env.GEMINI_API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [
            { text: 'Транскрибируй немецкую речь из аудио. Верни ТОЛЬКО JSON-массив без markdown-обёртки, формат: [{"start":число_секунд,"end":число_секунд,"de":"немецкая фраза","ru":"русский перевод"}]. Дели на короткие реплики по 3-8 секунд.' },
            { inlineData: { mimeType: payload.mimeType || 'audio/mp4', data: payload.audioBase64 } }
          ]
        }]
      })
    }
  );
  const data = await geminiResp.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '[]';
  return jsonResponse({ text });
}
```

### Важные ограничения, о которых стоит знать
- Инлайновая передача аудио (`inlineData` base64) у Gemini ограничена по размеру запроса (обычно около 20 МБ на весь payload). Для короткого ролика/сцены (несколько минут) это нормально; для целого фильма извлечённая дорожка может быть больше — тогда Gemini REST понадобится File API (сначала загрузить файл отдельным запросом, потом сослаться на него), это уже отдельная доработка Worker'а.
- Для теста стоит сначала попробовать на 2-3-минутном отрывке, а не сразу на полном фильме.

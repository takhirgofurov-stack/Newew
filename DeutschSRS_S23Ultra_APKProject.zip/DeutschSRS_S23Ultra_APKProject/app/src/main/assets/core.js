/* Testable core helpers shared by the Android WebView and Node.js tests. */
function localDateKey(date) {
  const d = date || new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function getSrsIntervals(state) {
  if (!state || !state.reps) return [20 / 1440, 2 / 24, 1, 3];
  const ease = Number(state.ease) || 2.5;
  const current = Math.max(0.01, Number(state.interval) || 0);
  return [20 / 1440, Math.max(2 / 24, current * 1.2), Math.max(1, current * ease), Math.max(3, current * ease * 1.3)];
}

function reviewSrsState(state, rating, now) {
  if (!Number.isInteger(rating) || rating < 0 || rating > 3) throw new RangeError('rating must be an integer from 0 to 3');
  const reviewedAt = Number.isFinite(now) ? now : Date.now();
  const source = state || {};
  const next = {
    reps: Number(source.reps) || 0,
    interval: Number(source.interval) || 0,
    ease: Number(source.ease) || 2.5,
    lapses: Number(source.lapses) || 0,
    h: Array.isArray(source.h) ? source.h.slice() : []
  };
  const interval = getSrsIntervals(source)[rating];
  if (rating === 0) {
    next.reps = 0;
    next.lapses += 1;
    next.ease = Math.max(1.3, next.ease - 0.2);
  } else {
    next.reps += 1;
    next.ease = Math.min(3.2, Math.max(1.3, next.ease + [0, -0.15, 0.03, 0.12][rating]));
  }
  next.interval = interval;
  next.last = reviewedAt;
  next.next = reviewedAt + interval * 86400000;
  next.h = [...next.h, rating].slice(-100);
  return next;
}

function normaliseRecall(value) {
  return String(value || '').toLocaleLowerCase('de-DE').trim().normalize('NFC')
    .replace(/[.!?,;:]+$/g, '').replace(/\s+/g, ' ');
}

function recallMatches(input, target, type) {
  const variants = new Set();
  const add = value => {
    if (!value) return;
    const normalized = normaliseRecall(value);
    variants.add(normalized);
    variants.add(normalized.replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss'));
  };
  const raw = String(target || '');
  add(raw);
  add(raw.replace(/\s*\(sich\)/i, ''));
  add(raw.replace(/^sich\s+/i, ''));
  add(raw.replace(/\s*\(sich\)/i, '').replace(/^sich\s+/i, ''));
  add(raw.replace(/^sich\s+(.+)$/i, '$1(sich)'));
  const canonical = value => {
    let result = normaliseRecall(value);
    if (type === 'verb') result = result.replace(/^sich\s+/i, '').replace(/\s*\(sich\)$/i, '');
    return result.replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss');
  };
  const answer = canonical(input);
  return Array.from(variants).some(value => canonical(value) === answer);
}

function srtTimeToSec(value) {
  const text = String(value == null ? '' : value).trim();
  let match = text.match(/^(\d+):([0-5]?\d):([0-5]?\d)(?:[.,](\d{1,3}))?$/);
  if (match) {
    return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]) + Number((match[4] || '0').padEnd(3, '0')) / 1000;
  }
  match = text.match(/^(\d+):([0-5]?\d)(?:[.,](\d{1,3}))?$/);
  if (match) {
    return Number(match[1]) * 60 + Number(match[2]) + Number((match[3] || '0').padEnd(3, '0')) / 1000;
  }
  return Number.NaN;
}

function srtTimeFormat(seconds) {
  let totalMs = Math.max(0, Math.round((Number(seconds) || 0) * 1000));
  const hours = Math.floor(totalMs / 3600000);
  totalMs -= hours * 3600000;
  const minutes = Math.floor(totalMs / 60000);
  totalMs -= minutes * 60000;
  const wholeSeconds = Math.floor(totalMs / 1000);
  const millis = totalMs - wholeSeconds * 1000;
  const pad = (n, len) => String(n).padStart(len, '0');
  return `${pad(hours, 2)}:${pad(minutes, 2)}:${pad(wholeSeconds, 2)},${pad(millis, 3)}`;
}

function parseSubtitleBlocks(input, isVtt) {
  const text = String(input == null ? '' : input).replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
  const cues = [];
  for (const block of text.split(/\n[ \t]*\n+/)) {
    const lines = block.split('\n');
    const timeLineIndex = lines.findIndex(line => line.includes('-->'));
    if (timeLineIndex < 0) continue;
    const timing = lines[timeLineIndex].split('-->');
    if (timing.length < 2) continue;
    const start = srtTimeToSec(timing[0]);
    const end = srtTimeToSec(timing[1].trim().split(/\s+/)[0]);
    const body = lines.slice(timeLineIndex + 1).join(' ')
      .replace(/<[^>]*>/g, '')
      .replace(/\{\\an\d+\}/gi, '')
      .trim();
    if (!body || !Number.isFinite(start) || !Number.isFinite(end) || end <= start) continue;
    cues.push({ start, end, text: body });
  }
  return cues;
}

function parseSRT(text) { return parseSubtitleBlocks(text, false); }
function parseVTT(text) { return parseSubtitleBlocks(String(text || '').replace(/^\uFEFF?WEBVTT[^\n]*(?:\n|$)/i, ''), true); }
function parseSubtitleAuto(text) {
  const clean = String(text == null ? '' : text).replace(/^\uFEFF/, '').trimStart();
  return /^WEBVTT(?:\s|$)/i.test(clean) ? parseVTT(clean) : parseSRT(clean);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { localDateKey, getSrsIntervals, reviewSrsState, normaliseRecall, recallMatches, srtTimeToSec, srtTimeFormat, parseSRT, parseVTT, parseSubtitleAuto };
}

package com.deutschsrs.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private FrameLayout rootLayout;
    private FrameLayout fullscreenContainer;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    private static final int REQ_SPEECH = 4201;
    private static final int REQ_PICK_VIDEO = 4202;
    private static final int REQ_PICK_SUBTITLE = 4204;
    private static final int REQ_PICK_SUBTITLE_RU = 4206;
    private static final int REQ_PICK_SUBTITLE_TRANSLATE = 4207;
    private static final int REQ_EXPORT_SRT = 4205;
    private static final int REQ_PICK_PROGRESS = 4208;
    private static final int REQ_EXPORT_PROGRESS = 4209;
    private static final int MAX_TEXT_IMPORT_BYTES = 8 * 1024 * 1024;
    private String pendingSrtContent;
    private String pendingProgressJson;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        installCrashHandler();
        migrateCachedMediaToPersistentStorage();

        rootLayout = new FrameLayout(this);

        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setVisibility(View.GONE);
        fullscreenContainer.setBackgroundColor(0xFF000000);

        setupWebView();

        rootLayout.addView(fullscreenContainer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(rootLayout);
        // targetSdk 35+ uses edge-to-edge on Android 15+. Keep the WebView content
        // inside the safe area so controls do not sit under system bars.
        rootLayout.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public android.view.WindowInsets onApplyWindowInsets(View view, android.view.WindowInsets insets) {
                int left, top, right, bottom;
                if (android.os.Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                    left = bars.left; top = bars.top; right = bars.right; bottom = bars.bottom;
                } else {
                    left = insets.getSystemWindowInsetLeft(); top = insets.getSystemWindowInsetTop();
                    right = insets.getSystemWindowInsetRight(); bottom = insets.getSystemWindowInsetBottom();
                }
                view.setPadding(left, top, right, bottom);
                return insets;
            }
        });
        rootLayout.requestApplyInsets();

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int r = tts.setLanguage(Locale.GERMANY);
                    ttsReady = (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED);
                }
            }
        });

        showLastCrashIfAny();
    }

    private void migrateCachedMediaToPersistentStorage() {
        String[] names = {"current_video.mp4", "current_audio.m4a"};
        for (String name : names) {
            File oldFile = new File(getCacheDir(), name);
            File newFile = new File(getFilesDir(), name);
            if (!oldFile.exists() || newFile.exists()) continue;
            try (InputStream in = new FileInputStream(oldFile); OutputStream out = new FileOutputStream(newFile)) {
                byte[] buffer = new byte[1 << 16];
                int read;
                while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                out.flush();
            } catch (Throwable e) {
                // A missing/cleared cache is recoverable: the UI asks the user to re-select the media.
            }
        }
    }

    // ---------- создание/пересоздание WebView (нужно и при старте, и после краша рендерера) ----------
    private void setupWebView() {
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        // Needed for app-private video files and local HTML; do not let a local
        // file page bypass the browser origin policy to read arbitrary origins.
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setBackgroundColor(0xFFF6F7FB);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setWebViewClient(new AppWebViewClient());
        web.setWebChromeClient(new AppChromeClient());
        web.addJavascriptInterface(new VoiceBridge(), "AndroidVoice");
        web.addJavascriptInterface(new VideoBridge(), "AndroidVideo");
        web.addJavascriptInterface(new AudioExtractBridge(), "AndroidAudio");
        web.addJavascriptInterface(new TtsBridge(), "AndroidTts");
        web.addJavascriptInterface(new SubtitleBridge(), "AndroidSubtitle");
        web.addJavascriptInterface(new TranscribeBridge(), "AndroidTranscribe");
        web.addJavascriptInterface(new OrientationBridge(), "AndroidOrientation");
        web.addJavascriptInterface(new ProgressBridge(), "AndroidProgress");
        web.loadUrl("file:///android_asset/index.html");
        rootLayout.addView(web, 0, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void recreateWebView() {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                setupWebView();
                Toast.makeText(MainActivity.this, "Внутренний веб-движок перезапустился после сбоя (не хватило памяти) — данные не потерялись, они сохраняются локально.", Toast.LENGTH_LONG).show();
            }
        });
    }

    // ---------- падение/убийство процесса рендерера WebView — это НЕ ловится обычным try/catch в Java ----------
    private class AppWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
            Uri uri = request.getUrl();
            String value = uri == null ? "" : uri.toString();
            if (value.startsWith("file:///android_asset/")) return false;
            String scheme = uri == null ? "" : String.valueOf(uri.getScheme()).toLowerCase(Locale.ROOT);
            if (("https".equals(scheme) || "http".equals(scheme)) && request.isForMainFrame()) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Не удалось открыть ссылку: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            // External pages and unrecognized schemes never load inside the WebView
            // where the Android JavaScript bridges are exposed.
            return true;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (url != null && url.startsWith("file:///android_asset/")) return false;
            try {
                Uri uri = Uri.parse(url);
                String scheme = String.valueOf(uri.getScheme()).toLowerCase(Locale.ROOT);
                if ("https".equals(scheme) || "http".equals(scheme)) startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        @Override
        public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
            try {
                String note = new java.util.Date().toString() + "\n"
                        + "WebView-процесс " + (detail.didCrash() ? "упал (renderer crash)" : "был принудительно закрыт системой — почти всегда из-за нехватки памяти во время обработки видео/звука") + ".\n"
                        + "Для этого типа сбоя Android не даёт подробный стектрейс.";
                getSharedPreferences(CRASH_PREFS, MODE_PRIVATE).edit().putString(CRASH_KEY, note).commit();
            } catch (Throwable ignore) { }

            ViewGroup parent = (ViewGroup) view.getParent();
            if (parent != null) parent.removeView(view);
            view.destroy();
            recreateWebView();
            return true;
        }
    }

    // ---------- перехват крашей: сохраняем стектрейс, чтобы показать его при следующем запуске ----------
    private static final String CRASH_PREFS = "crash_log_prefs";
    private static final String CRASH_KEY = "last_crash";

    private void installCrashHandler() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread t, Throwable e) {
                try {
                    StringWriter sw = new StringWriter();
                    PrintWriter pw = new PrintWriter(sw);
                    pw.println(new java.util.Date().toString());
                    pw.println("Thread: " + t.getName());
                    e.printStackTrace(pw);
                    String trace = sw.toString();
                    SharedPreferences prefs = getSharedPreferences(CRASH_PREFS, MODE_PRIVATE);
                    prefs.edit().putString(CRASH_KEY, trace).commit();
                } catch (Throwable ignore) { }
                if (previous != null) {
                    previous.uncaughtException(t, e);
                } else {
                    android.os.Process.killProcess(android.os.Process.myPid());
                    System.exit(10);
                }
            }
        });
    }

    private void showLastCrashIfAny() {
        final SharedPreferences prefs = getSharedPreferences(CRASH_PREFS, MODE_PRIVATE);
        final String trace = prefs.getString(CRASH_KEY, null);
        if (trace == null || trace.trim().length() == 0) return;
        new AlertDialog.Builder(this)
                .setTitle("Приложение упало в прошлый раз")
                .setMessage(trace)
                .setPositiveButton("Поделиться", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("text/plain");
                        send.putExtra(Intent.EXTRA_TEXT, trace);
                        try {
                            startActivity(Intent.createChooser(send, "Отправить лог краша"));
                        } catch (Exception ignore) { }
                        prefs.edit().remove(CRASH_KEY).apply();
                    }
                })
                .setNegativeButton("Закрыть", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().remove(CRASH_KEY).apply();
                    }
                })
                .setCancelable(false)
                .show();
    }

    // ---------- полноэкранное видео (fullscreen для <video>) ----------
    private class AppChromeClient extends WebChromeClient {
        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (customView != null) {
                callback.onCustomViewHidden();
                return;
            }
            customView = view;
            customViewCallback = callback;
            web.setVisibility(View.GONE);
            fullscreenContainer.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            fullscreenContainer.setVisibility(View.VISIBLE);
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;
            web.setVisibility(View.VISIBLE);
            fullscreenContainer.setVisibility(View.GONE);
            fullscreenContainer.removeView(customView);
            if (customViewCallback != null) customViewCallback.onCustomViewHidden();
            customView = null;
            customViewCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            ((AppChromeClient) web.getWebChromeClient()).onHideCustomView();
        } else {
            super.onBackPressed();
        }
    }

    // ---------- нативная озвучка немецкого текста (надёжнее, чем speechSynthesis в WebView) ----------
    private class TtsBridge {
        @JavascriptInterface
        public void speak(final String text) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (tts != null && ttsReady) {
                        tts.stop();
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utt1");
                    } else {
                        Toast.makeText(MainActivity.this,
                                "Немецкий голос не найден. Настройки → Общее управление → Языки и время → Синтез речи → добавить немецкий.",
                                Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (tts != null) tts.stop();
                }
            });
        }

        @JavascriptInterface
        public String getEngines() {
            JSONArray arr = new JSONArray();
            try {
                List<TextToSpeech.EngineInfo> engines =
                        (tts != null) ? tts.getEngines() : new ArrayList<TextToSpeech.EngineInfo>();
                for (TextToSpeech.EngineInfo e : engines) {
                    JSONObject o = new JSONObject();
                    o.put("name", e.name);
                    o.put("label", e.label);
                    arr.put(o);
                }
            } catch (Exception ex) {
                // отдаём пустой список, JS покажет "недоступно"
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void setEngine(final String enginePackage) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (tts != null) {
                        tts.stop();
                        tts.shutdown();
                    }
                    ttsReady = false;
                    tts = new TextToSpeech(MainActivity.this, new TextToSpeech.OnInitListener() {
                        @Override public void onInit(int status) {
                            if (status == TextToSpeech.SUCCESS) {
                                int r = tts.setLanguage(Locale.GERMANY);
                                ttsReady = (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED);
                            }
                            final boolean ok = ttsReady;
                            web.post(new Runnable() {
                                @Override public void run() {
                                    web.evaluateJavascript("window.onTtsEngineReady && window.onTtsEngineReady(" + ok + ");", null);
                                }
                            });
                        }
                    }, enginePackage);
                }
            });
        }

        @JavascriptInterface
        public String getVoices() {
            JSONArray arr = new JSONArray();
            try {
                if (tts != null && ttsReady) {
                    for (Voice v : tts.getVoices()) {
                        if (v.getLocale() != null && "de".equals(v.getLocale().getLanguage())) {
                            JSONObject o = new JSONObject();
                            o.put("name", v.getName());
                            o.put("quality", v.getQuality());
                            o.put("network", v.isNetworkConnectionRequired());
                            o.put("locale", v.getLocale().toString());
                            arr.put(o);
                        }
                    }
                }
            } catch (Exception ex) {
                // отдаём пустой список при любой ошибке
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void setVoice(final String voiceName) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (tts == null) return;
                    try {
                        for (Voice v : tts.getVoices()) {
                            if (v.getName().equals(voiceName)) {
                                tts.setVoice(v);
                                break;
                            }
                        }
                    } catch (Exception ex) {
                        Toast.makeText(MainActivity.this, "Не удалось выбрать голос: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    // ---------- голосовой ввод (кнопка микрофона в чате) ----------
    private class VoiceBridge {
        @JavascriptInterface
        public void startListening() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE");
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Sprich auf Deutsch…");
                    if (intent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(intent, REQ_SPEECH);
                    } else {
                        Toast.makeText(MainActivity.this, "Голосовой ввод недоступен на этом устройстве", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    // ---------- выбор видеофайла (этап 1 функции субтитров) ----------
    private class VideoBridge {
        @JavascriptInterface
        public void pickVideo() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("video/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        startActivityForResult(intent, REQ_PICK_VIDEO);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Не удалось открыть выбор файлов: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    // ---------- извлечение звуковой дорожки из видео (этап 2) ----------
    private class AudioExtractBridge {
        @JavascriptInterface
        public void extractAudio() {
            web.post(new Runnable() {
                @Override public void run() {
                    web.evaluateJavascript("window.onAudioExtractStart && window.onAudioExtractStart();", null);
                }
            });
            new Thread(new Runnable() {
                @Override public void run() {
                    MediaExtractor extractor = null;
                    MediaMuxer muxer = null;
                    try {
                        File videoFile = new File(getFilesDir(), "current_video.mp4");
                        if (!videoFile.exists()) {
                            throw new Exception("Видео не найдено — выберите видео заново");
                        }
                        File audioFile = new File(getFilesDir(), "current_audio.m4a");

                        extractor = new MediaExtractor();
                        extractor.setDataSource(videoFile.getAbsolutePath());

                        int audioTrackIndex = -1;
                        MediaFormat audioFormat = null;
                        int trackCount = extractor.getTrackCount();
                        for (int i = 0; i < trackCount; i++) {
                            MediaFormat format = extractor.getTrackFormat(i);
                            String mime = format.getString(MediaFormat.KEY_MIME);
                            if (mime != null && mime.startsWith("audio/")) {
                                audioTrackIndex = i;
                                audioFormat = format;
                                break;
                            }
                        }
                        if (audioTrackIndex == -1) {
                            throw new Exception("В этом видео не найдена звуковая дорожка");
                        }
                        extractor.selectTrack(audioTrackIndex);

                        muxer = new MediaMuxer(audioFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                        int outTrackIndex = muxer.addTrack(audioFormat);
                        muxer.start();

                        ByteBuffer buffer = ByteBuffer.allocate(1 << 20);
                        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
                        long totalDurationUs = audioFormat.containsKey(MediaFormat.KEY_DURATION)
                                ? audioFormat.getLong(MediaFormat.KEY_DURATION) : 0;
                        int lastPercentSent = -1;

                        while (true) {
                            buffer.clear();
                            int sampleSize = extractor.readSampleData(buffer, 0);
                            if (sampleSize < 0) break;
                            bufferInfo.offset = 0;
                            bufferInfo.size = sampleSize;
                            bufferInfo.presentationTimeUs = extractor.getSampleTime();
                            bufferInfo.flags = extractor.getSampleFlags();
                            muxer.writeSampleData(outTrackIndex, buffer, bufferInfo);

                            if (totalDurationUs > 0) {
                                final int percent = (int) Math.min(100, (bufferInfo.presentationTimeUs * 100) / totalDurationUs);
                                if (percent != lastPercentSent) {
                                    lastPercentSent = percent;
                                    web.post(new Runnable() {
                                        @Override public void run() {
                                            web.evaluateJavascript("window.onAudioExtractProgress && window.onAudioExtractProgress(" + percent + ");", null);
                                        }
                                    });
                                }
                            }
                            extractor.advance();
                        }

                        muxer.stop();
                        muxer.release();
                        muxer = null;
                        extractor.release();
                        extractor = null;

                        final long audioSizeBytes = audioFile.length();
                        final double durationSec = totalDurationUs > 0 ? totalDurationUs / 1_000_000.0 : 0;
                        final String escapedPath = JSONObject.quote("file://" + audioFile.getAbsolutePath());
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onAudioExtracted && window.onAudioExtracted(" + escapedPath + ", " + audioSizeBytes + ", " + durationSec + ");", null);
                            }
                        });
                    } catch (Throwable e) {
                        try { if (muxer != null) muxer.release(); } catch (Exception ignore) { }
                        try { if (extractor != null) extractor.release(); } catch (Exception ignore) { }
                        final String escapedErr = JSONObject.quote(String.valueOf(e.getMessage()));
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onAudioExtractError && window.onAudioExtractError(" + escapedErr + ");", null);
                            }
                        });
                    }
                }
            }).start();
        }
    }

    // ---------- выбор файла субтитров .srt/.vtt (этап 3, вариант «готовый файл») ----------
    private class SubtitleBridge {
        @JavascriptInterface
        public void pickSubtitle() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        startActivityForResult(intent, REQ_PICK_SUBTITLE);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Не удалось открыть выбор файлов: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void pickSubtitleRu() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        startActivityForResult(intent, REQ_PICK_SUBTITLE_RU);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Не удалось открыть выбор файлов: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void pickSubtitleForTranslate() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        startActivityForResult(intent, REQ_PICK_SUBTITLE_TRANSLATE);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Не удалось открыть выбор файлов: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void exportSrt(final String content) {
            pendingSrtContent = content;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_TITLE, "subtitles.srt");
                    try {
                        startActivityForResult(intent, REQ_EXPORT_SRT);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Не удалось открыть сохранение файла: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    // ---------- экспорт и импорт резервной копии учебного прогресса ----------
    private class ProgressBridge {
        @JavascriptInterface
        public void exportProgress(final String json) {
            if (json == null || json.length() > 8 * 1024 * 1024) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Toast.makeText(MainActivity.this, "Резервная копия слишком большая (максимум 8 МиБ). Удали старые сообщения чата или AI-примеры и попробуй снова.", Toast.LENGTH_LONG).show();
                    }
                });
                return;
            }
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    pendingProgressJson = json;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, "deutsch-srs-backup.json");
                    try { startActivityForResult(intent, REQ_EXPORT_PROGRESS); }
                    catch (Exception e) {
                        pendingProgressJson = null;
                        Toast.makeText(MainActivity.this, "Не удалось открыть сохранение: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void pickProgress() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivityForResult(intent, REQ_PICK_PROGRESS); }
                    catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Не удалось открыть выбор файла: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    // ---------- отправка извлечённого звука в Gemini через Cloudflare Worker (этап 3, вариант «распознать через ИИ») ----------
    // ---------- потоковая отправка аудиофайла на Worker без промежуточных копий целиком в памяти ----------
    // ---------- чтение выбранного текстового файла (субтитры/перевод) с вызовом нужного JS-колбэка ----------
    private void readTextFileAndCallback(final Uri uri, final String successCallback, final String errorCallback) {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final String text;
                    try (InputStream in = getContentResolver().openInputStream(uri);
                         ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                        if (in == null) throw new Exception("Не удалось открыть выбранный файл");
                        byte[] buf = new byte[1 << 16];
                        int n;
                        while ((n = in.read(buf)) != -1) {
                            if (bos.size() + n > MAX_TEXT_IMPORT_BYTES) {
                                throw new Exception("Текстовый файл слишком большой (максимум 8 МиБ)");
                            }
                            bos.write(buf, 0, n);
                        }
                        String decoded = new String(bos.toByteArray(), StandardCharsets.UTF_8);
                        text = decoded.length() > 0 && decoded.charAt(0) == '\uFEFF' ? decoded.substring(1) : decoded;
                    }
                    final String escaped = JSONObject.quote(text);
                    web.post(new Runnable() {
                        @Override public void run() {
                            web.evaluateJavascript("window." + successCallback + " && window." + successCallback + "(" + escaped + ");", null);
                        }
                    });
                } catch (Throwable e) {
                    final String escapedErr = JSONObject.quote(String.valueOf(e.getMessage()));
                    web.post(new Runnable() {
                        @Override public void run() {
                            web.evaluateJavascript("window." + errorCallback + " && window." + errorCallback + "(" + escapedErr + ");", null);
                        }
                    });
                }
            }
        }).start();
    }

    private String postAudioForTranscription(String workerUrl, String secret, File audioFile, String mimeType) throws Exception {
        long fileLen = audioFile.length();
        byte[] prefixBytes = ("{\"mode\":\"transcribeSubtitles\",\"mimeType\":\"" + mimeType + "\",\"audioBase64\":\"").getBytes(StandardCharsets.UTF_8);
        byte[] suffixBytes = "\"}".getBytes(StandardCharsets.UTF_8);
        long encodedLen = ((fileLen + 2) / 3) * 4;
        long totalLen = prefixBytes.length + encodedLen + suffixBytes.length;

        URL url = new URL(workerUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        try {
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(180000);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("X-App-Secret", secret == null ? "" : secret);
            conn.setFixedLengthStreamingMode(totalLen);

            OutputStream os = conn.getOutputStream();
            os.write(prefixBytes);
            os.flush();

            android.util.Base64OutputStream b64out = new android.util.Base64OutputStream(os, android.util.Base64.NO_WRAP | android.util.Base64.NO_CLOSE);
            FileInputStream fis = new FileInputStream(audioFile);
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = fis.read(buf)) != -1) {
                b64out.write(buf, 0, n);
            }
            fis.close();
            b64out.flush();
            b64out.close();

            os.write(suffixBytes);
            os.flush();
            os.close();

            int code = conn.getResponseCode();
            InputStream respStream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] rbuf = new byte[1 << 16];
            int rn;
            while (respStream != null && (rn = respStream.read(rbuf)) != -1) {
                bos.write(rbuf, 0, rn);
            }
            if (respStream != null) respStream.close();
            String respText = new String(bos.toByteArray(), StandardCharsets.UTF_8);

            if (code < 200 || code >= 300) {
                throw new Exception("HTTP " + code + ": " + respText);
            }
            return respText;
        } finally {
            conn.disconnect();
        }
    }

    private class TranscribeBridge {
        @JavascriptInterface
        public void transcribe(final String workerUrl, final String secret) {
            web.post(new Runnable() {
                @Override public void run() {
                    web.evaluateJavascript("window.onTranscribeStart && window.onTranscribeStart();", null);
                }
            });
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        File audioFile = new File(getFilesDir(), "current_audio.m4a");
                        if (!audioFile.exists()) {
                            throw new Exception("Сначала извлеки звук из видео на предыдущем шаге");
                        }

                        String respText = postAudioForTranscription(workerUrl, secret, audioFile, "audio/mp4");

                        final String escaped = JSONObject.quote(respText);
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onTranscribeResult && window.onTranscribeResult(" + escaped + ");", null);
                            }
                        });
                    } catch (Throwable e) {
                        final String escapedErr = JSONObject.quote(String.valueOf(e.getMessage()));
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onTranscribeError && window.onTranscribeError(" + escapedErr + ");", null);
                            }
                        });
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void transcribeChunk(final String workerUrl, final String secret, final double startSec, final double endSec, final int chunkIndex, final int totalChunks) {
            web.post(new Runnable() {
                @Override public void run() {
                    web.evaluateJavascript("window.onTranscribeChunkStart && window.onTranscribeChunkStart(" + chunkIndex + ", " + totalChunks + ");", null);
                }
            });
            new Thread(new Runnable() {
                @Override public void run() {
                    MediaExtractor extractor = null;
                    MediaMuxer muxer = null;
                    File chunkFile = null;
                    try {
                        File audioFile = new File(getFilesDir(), "current_audio.m4a");
                        if (!audioFile.exists()) {
                            throw new Exception("Сначала извлеки звук из видео на предыдущем шаге");
                        }
                        chunkFile = new File(getCacheDir(), "chunk_" + chunkIndex + ".m4a");

                        extractor = new MediaExtractor();
                        extractor.setDataSource(audioFile.getAbsolutePath());
                        if (extractor.getTrackCount() == 0) {
                            throw new Exception("В извлечённом звуке нет дорожек");
                        }
                        MediaFormat format = extractor.getTrackFormat(0);
                        extractor.selectTrack(0);

                        long startUs = (long) (startSec * 1_000_000L);
                        long endUs = (long) (endSec * 1_000_000L);
                        extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);

                        muxer = new MediaMuxer(chunkFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                        int outTrack = muxer.addTrack(format);
                        muxer.start();

                        ByteBuffer buffer = ByteBuffer.allocate(1 << 20);
                        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                        long basePts = -1;
                        long lastSampleTime = -1;

                        while (true) {
                            long sampleTime = extractor.getSampleTime();
                            if (sampleTime < 0 || sampleTime > endUs) break;
                            buffer.clear();
                            int sampleSize = extractor.readSampleData(buffer, 0);
                            if (sampleSize < 0) break;
                            if (basePts < 0) basePts = sampleTime;
                            lastSampleTime = sampleTime;
                            info.offset = 0;
                            info.size = sampleSize;
                            info.presentationTimeUs = Math.max(0, sampleTime - basePts);
                            info.flags = extractor.getSampleFlags();
                            muxer.writeSampleData(outTrack, buffer, info);
                            if (!extractor.advance()) break;
                        }

                        muxer.stop();
                        muxer.release();
                        muxer = null;
                        extractor.release();
                        extractor = null;

                        if (!chunkFile.exists() || chunkFile.length() < 200) {
                            throw new Exception("Пустой фрагмент — похоже, звук уже закончился раньше этой части");
                        }

                        final double actualStartSec = basePts >= 0 ? basePts / 1_000_000.0 : startSec;
                        String respText = postAudioForTranscription(workerUrl, secret, chunkFile, "audio/mp4");

                        final String escaped = JSONObject.quote(respText);
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onTranscribeChunkResult && window.onTranscribeChunkResult(" + chunkIndex + ", " + totalChunks + ", " + actualStartSec + ", " + escaped + ");", null);
                            }
                        });
                    } catch (Throwable e) {
                        final String escapedErr = JSONObject.quote(String.valueOf(e.getMessage()));
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onTranscribeChunkError && window.onTranscribeChunkError(" + chunkIndex + ", " + totalChunks + ", " + escapedErr + ");", null);
                            }
                        });
                    } finally {
                        try { if (muxer != null) muxer.release(); } catch (Exception ignore) { }
                        try { if (extractor != null) extractor.release(); } catch (Exception ignore) { }
                        if (chunkFile != null) chunkFile.delete();
                    }
                }
            }).start();
        }
    }

    // ---------- блокировка ориентации для «театрального» просмотра видео с субтитрами ----------
    private class OrientationBridge {
        @JavascriptInterface
        public void lockLandscape() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                }
            });
        }
        @JavascriptInterface
        public void unlock() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                final String escaped = JSONObject.quote(results.get(0));
                web.post(new Runnable() {
                    @Override public void run() {
                        web.evaluateJavascript("window.onSpeechResult && window.onSpeechResult(" + escaped + ");", null);
                    }
                });
            }
            return;
        }

        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            final Uri uri = data.getData();
            if (uri == null) return;
            web.post(new Runnable() {
                @Override public void run() {
                    web.evaluateJavascript("window.onVideoImportStart && window.onVideoImportStart();", null);
                }
            });
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        File outFile = new File(getFilesDir(), "current_video.mp4");
                        ContentResolver cr = getContentResolver();
                        byte[] buf = new byte[1 << 16];
                        int n;
                        try (InputStream in = cr.openInputStream(uri)) {
                            if (in == null) throw new Exception("Не удалось открыть выбранное видео");
                            try (OutputStream out = new FileOutputStream(outFile)) {
                                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                                out.flush();
                            }
                        }
                        final String escapedPath = JSONObject.quote("file://" + outFile.getAbsolutePath());
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onVideoImported && window.onVideoImported(" + escapedPath + ");", null);
                            }
                        });
                    } catch (Throwable e) {
                        final String escapedErr = JSONObject.quote(String.valueOf(e.getMessage()));
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onVideoImportError && window.onVideoImportError(" + escapedErr + ");", null);
                            }
                        });
                    }
                }
            }).start();
        }

        if (requestCode == REQ_PICK_SUBTITLE && resultCode == RESULT_OK && data != null) {
            final Uri uri = data.getData();
            if (uri != null) readTextFileAndCallback(uri, "onSubtitleImported", "onSubtitleImportError");
        }

        if (requestCode == REQ_PICK_SUBTITLE_RU && resultCode == RESULT_OK && data != null) {
            final Uri uri = data.getData();
            if (uri != null) readTextFileAndCallback(uri, "onSubtitleRuImported", "onSubtitleRuImportError");
        }

        if (requestCode == REQ_PICK_SUBTITLE_TRANSLATE && resultCode == RESULT_OK && data != null) {
            final Uri uri = data.getData();
            if (uri != null) readTextFileAndCallback(uri, "onSubtitleForTranslateImported", "onSubtitleForTranslateImportError");
        }

        if (requestCode == REQ_PICK_PROGRESS && resultCode == RESULT_OK && data != null) {
            final Uri uri = data.getData();
            if (uri != null) readTextFileAndCallback(uri, "onProgressImported", "onProgressImportError");
        }

        if (requestCode == REQ_EXPORT_PROGRESS) {
            final Uri uri = resultCode == RESULT_OK && data != null ? data.getData() : null;
            final String content = pendingProgressJson;
            pendingProgressJson = null;
            if (uri != null && content != null) {
                new Thread(new Runnable() {
                    @Override public void run() {
                        try {
                            OutputStream out = getContentResolver().openOutputStream(uri);
                            if (out == null) throw new Exception("Не удалось открыть файл для записи");
                            try { out.write(content.getBytes(StandardCharsets.UTF_8)); out.flush(); }
                            finally { out.close(); }
                            runOnUiThread(new Runnable() {
                                @Override public void run() { Toast.makeText(MainActivity.this, "Резервная копия сохранена", Toast.LENGTH_LONG).show(); }
                            });
                        } catch (Throwable e) {
                            final String msg = String.valueOf(e.getMessage());
                            runOnUiThread(new Runnable() {
                                @Override public void run() { Toast.makeText(MainActivity.this, "Не удалось сохранить копию: " + msg, Toast.LENGTH_LONG).show(); }
                            });
                        }
                    }
                }).start();
            }
        }

        if (requestCode == REQ_EXPORT_SRT && resultCode == RESULT_OK && data != null) {
            final Uri uri = data.getData();
            final String content = pendingSrtContent;
            pendingSrtContent = null;
            if (uri == null || content == null) return;
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        ContentResolver cr = getContentResolver();
                        OutputStream out = cr.openOutputStream(uri);
                        if (out != null) {
                            out.write(content.getBytes(StandardCharsets.UTF_8));
                            out.flush();
                            out.close();
                        }
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                Toast.makeText(MainActivity.this, "Субтитры сохранены", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } catch (Throwable e) {
                        final String msg = String.valueOf(e.getMessage());
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                Toast.makeText(MainActivity.this, "Не удалось сохранить: " + msg, Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }
            }).start();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            try { ((ViewGroup) web.getParent()).removeView(web); } catch (Exception ignore) { }
            web.destroy();
            web = null;
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const assets = path.join(root, 'app/src/main/assets');
const decks = JSON.parse(fs.readFileSync(path.join(assets, 'decks.json'), 'utf8'));
assert.equal(decks.verbs.length, 1170);
assert.equal(decks.adverbs.length, 402);
assert.equal(decks.preps.length, 67);
for (const [deck, field] of [['verbs','verb'], ['adverbs','word'], ['preps','word']]) {
  const keys = decks[deck].map(item => String(item[field] || '').trim().toLocaleLowerCase());
  assert.ok(keys.every(Boolean), `${deck} has no empty ${field}`);
  assert.equal(new Set(keys).size, keys.length, `${deck} has duplicate ${field}`);
}
assert.ok(decks.verbs.every(v => v.partizip && !/^(?:ist|ist\/hat)\s/i.test(v.partizip)), 'Partizip II should not include the auxiliary verb');
assert.equal(decks.verbs.filter(v => v.auxiliary).length, 149, 'auxiliary metadata should preserve previously embedded auxiliary information');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
assert.match(html, /<script src="cards\.js"><\/script>/);
assert.match(html, /<script src="core\.js"><\/script>/);
assert.doesNotMatch(html, /const CARDS=\[/, 'large card data must not be duplicated in HTML');
const cardJs = fs.readFileSync(path.join(assets, 'cards.js'), 'utf8');
assert.match(cardJs, /const CARDS=/);
assert.match(cardJs, /const ADVERBS=/);
assert.match(cardJs, /const PREPS=/);
const legacy = JSON.parse(fs.readFileSync(path.join(assets, 'cards.json'), 'utf8'));
assert.deepEqual(legacy, decks.verbs, 'legacy cards.json should be generated from canonical deck data');
console.log('Data tests passed: 1,170 verbs, 402 adverbs, 67 prepositions; canonical data and runtime assets are synchronized.');

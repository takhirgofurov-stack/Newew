const assert = require('node:assert/strict');
const core = require('../app/src/main/assets/core.js');

// Timestamp parsing supports classic SRT, long WebVTT and short WebVTT timestamps.
assert.equal(core.srtTimeToSec('01:02:03,045'), 3723.045);
assert.equal(core.srtTimeToSec('00:12.500'), 12.5);
assert.equal(core.srtTimeToSec('5:07.25'), 307.25);
assert.ok(Number.isNaN(core.srtTimeToSec('not-a-time')));
assert.equal(core.srtTimeFormat(1.9996), '00:00:02,000');
assert.equal(core.srtTimeFormat(-3), '00:00:00,000');

const srt = '\uFEFF1\r\n00:00:01,000 --> 00:00:02,500\r\nHallo <i>Welt</i>!\r\n\r\n2\r\n00:00:03,000 --> 00:00:04,000\r\nWie geht es dir?';
assert.deepEqual(core.parseSRT(srt), [
  {start: 1, end: 2.5, text: 'Hallo Welt!'},
  {start: 3, end: 4, text: 'Wie geht es dir?'}
]);
const vtt = 'WEBVTT - German subtitles\n\nintro\n00:12.500 --> 00:14.000 align:start\nGuten Morgen!\n\n00:14.000 --> 00:15.000\nAlles gut?';
assert.deepEqual(core.parseSubtitleAuto(vtt), [
  {start: 12.5, end: 14, text: 'Guten Morgen!'},
  {start: 14, end: 15, text: 'Alles gut?'}
]);
assert.equal(core.parseSRT('1\n00:00:04,000 --> 00:00:02,000\nBad interval').length, 0);

const fresh = core.getSrsIntervals(null);
assert.deepEqual(fresh, [20 / 1440, 2 / 24, 1, 3]);
const again = core.reviewSrsState(null, 0, 1000);
assert.equal(again.reps, 0);
assert.equal(again.lapses, 1);
assert.equal(again.next, 1000 + (20 / 1440) * 86400000);
const good = core.reviewSrsState(null, 2, 5000);
assert.equal(good.reps, 1);
assert.equal(good.interval, 1);
assert.equal(good.next, 5000 + 86400000);
const hard = core.reviewSrsState({reps: 3, interval: 5, ease: 2.3, h: [2]}, 1, 10000);
assert.equal(hard.reps, 4);
assert.ok(hard.interval >= 2 / 24);
assert.deepEqual(hard.h, [2, 1]);
assert.throws(() => core.reviewSrsState(null, 4, 1), RangeError);

const d = new Date(2026, 9, 11, 0, 1, 0);
assert.equal(core.localDateKey(d), '2026-10-11');
assert.equal(core.recallMatches('erinnern', 'erinnern(sich)', 'verb'), true);
assert.equal(core.recallMatches('sich erinnern', 'erinnern(sich)', 'verb'), true);
assert.equal(core.recallMatches('aufhoeren', 'aufhören', 'verb'), true);
assert.equal(core.recallMatches('jetzt', 'jetzt', 'adverb'), true);
assert.equal(core.recallMatches('jetztmal', 'jetzt', 'adverb'), false);
console.log('Core tests passed: SRT/VTT parsing, timestamp rounding, local dates and SRS scheduling.');

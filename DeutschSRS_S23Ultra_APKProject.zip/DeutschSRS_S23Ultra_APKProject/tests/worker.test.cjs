const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { spawnSync } = require('node:child_process');

(async () => {
  const workerSource = path.resolve(__dirname, '../../worker/cloudflare_worker_gemini.js');
  const temp = path.join(require('node:os').tmpdir(), `deutschsrs-worker-${process.pid}.mjs`);
  fs.copyFileSync(workerSource, temp);
  const module = await import(pathToFileURL(temp).href + `?t=${Date.now()}`);
  const worker = module.default;
  const call = (body, env = {}, headers = {}) => worker.fetch(new Request('https://example.test/', {
    method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body)
  }), env);
  try {
    let res = await worker.fetch(new Request('https://example.test/', { method: 'GET' }), {});
    assert.equal(res.status, 405);
    res = await call({ mode: 'chat', messages: [{ role: 'user', content: 'ping' }] }, { APP_SECRET: 'x', GEMINI_API_KEY: 'y' });
    assert.equal(res.status, 401);
    res = await call({ mode: 'chat', messages: [{ role: 'user', content: 'ping' }] }, { APP_SECRET: 'x' }, { 'X-App-Secret': 'x' });
    assert.equal(res.status, 503);
    res = await call({ mode: 'translateBatch', lines: Array(61).fill('Hallo') }, { APP_SECRET: 'x', GEMINI_API_KEY: 'y' }, { 'X-App-Secret': 'x' });
    assert.equal(res.status, 400);

    const originalFetch = global.fetch;
    global.fetch = async (_url, options) => {
      const payload = JSON.parse(options.body);
      assert.equal(payload.generationConfig.responseMimeType, 'application/json');
      return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: JSON.stringify({ translations: ['Привет'] }) }] } }] }), { status: 200 });
    };
    res = await call({ mode: 'translateBatch', lines: ['Hallo'] }, { APP_SECRET: 'x', GEMINI_API_KEY: 'y' }, { 'X-App-Secret': 'x' });
    assert.equal(res.status, 200);
    assert.deepEqual(await res.json(), { translations: ['Привет'] });
    global.fetch = async () => new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: JSON.stringify({ translations: [] }) }] } }] }), { status: 200 });
    res = await call({ mode: 'translateBatch', lines: ['Hallo'] }, { APP_SECRET: 'x', GEMINI_API_KEY: 'y' }, { 'X-App-Secret': 'x' });
    assert.equal(res.status, 502, 'incomplete translation batches must be reported');
    global.fetch = originalFetch;
    console.log('Worker tests passed: methods/auth/config validation, batch limits, successful and incomplete translation responses.');
  } finally {
    try { fs.unlinkSync(temp); } catch (_) {}
  }
})().catch(err => { console.error(err); process.exitCode = 1; });
